# tweetbotornot 0.0.3

* Renamed to tweetbotornot

# botornot 0.0.1

* Initial commit, featuring `botornot()` function and gradient boosted models
trained on real Twitter data (ten thousand accounts with over 7,000 bots).
* Added a `NEWS.md` file to track changes to the package.
