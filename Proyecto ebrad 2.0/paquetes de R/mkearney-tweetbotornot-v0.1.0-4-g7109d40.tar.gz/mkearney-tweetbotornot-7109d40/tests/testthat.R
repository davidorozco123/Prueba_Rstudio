library(testthat)
library(tweetbotornot)

test_check("tweetbotornot")
